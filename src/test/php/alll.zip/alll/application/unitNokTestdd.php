<?php
 
class PhpUnitTest extends PHPUnit_Framework_TestCase
{
    public function testAssertText()
    {
	$textToAssert = 'ok';
	$this->assertEquals('nok', $textToAssert);
    }
}
?>
