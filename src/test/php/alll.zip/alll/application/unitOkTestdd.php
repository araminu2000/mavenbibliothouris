<?php
 
class PhpUnit3Test extends PHPUnit_Framework_TestCase
{
    public function testAssertText()
    {
	$textToAssert = 'ok';
	$this->assertEquals('ok', $textToAssert);
    }
}
?>
